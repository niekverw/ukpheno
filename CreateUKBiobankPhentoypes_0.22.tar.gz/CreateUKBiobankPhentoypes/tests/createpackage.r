library(data.table)
#install.packages("devtools")
library("devtools")
#devtools::install_github("klutometis/roxygen")
library(roxygen2)

#setwd("/data_work/bitbucket/ukbio")
#create("CreateUKBiobankPhentoypes")
setwd("/data_work/bitbucket/ukbio/CreateUKBiobankPhentoypes")
document()
rm(dfDefinitions)
install("/data_work/bitbucket/ukbio/CreateUKBiobankPhentoypes")
library(CreateUKBiobankPhentoypes)
####
#remove.packages("CreateUKBiobankPhentoypes")

### save example dataset:
dfDefinitions_file_tsv="/data_work/bitbucket/ukbio/CreateUKBiobankPhentoypes/data/dfDefinitions.tsv"
dfDefinitions<-data.frame(fread(dfDefinitions_file_tsv))
dfDefinitions$Comment<-""
save(dfDefinitions, file="data/dfDefinitions.RData")
### save codesheet for treatment:
#dfCodesheetTreatment<-data.frame(fread("/data_work/bitbucket/ukbio/CreateUKBiobankPhentoypes/data/dfCodesheetTreatment.txt",header=T,sep="\t"))
dfCodesheetTreatment<- read.xls("/data_work/bitbucket/ukbio/CreateUKBiobankPhentoypes/data/UKBREADmap.xls", sheet=1, header=TRUE)
save(dfCodesheetTreatment, file="data/dfCodesheetTreatment.RData")
##### 

build()

install.packages( "/data_work/bitbucket/ukbio/CreateUKBiobankPhentoypes_0.21.tar.gz",type="source",repos=NULL)
install.packages( "CreateUKBiobankPhentoypes_0.21.tar.gz",type="source",repos=NULL)

library(CreateUKBiobankPhentoypes)

####

remove.packages("CreateUKBiobankPhentoypes")
unload(CreateUKBiobankPhentoypes)
CreateUKBiobankPhentoypes(3,2 ,UKbioDataset,dfmaster_SQL_merge=dfmaster_SQL_merge,dfSQL_TraitTable,Outputdir )

data(dfDefinitions)
data(dfCodesheetTreatment)
